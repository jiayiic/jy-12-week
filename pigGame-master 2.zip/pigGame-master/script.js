'use strict';
/* For any Question write me an Email at: codeWithJad@gmail.com */

//Selecting elemnts:
let winMode = false;
const winMessage = document.getElementById('win-message');
const winAudio = document.getElementById('win-audio');
const player0 = document.querySelector('.player--0');
const player1 = document.querySelector('.player--1');
const score0El = document.querySelector('#score--0');
const score1El = document.querySelector('#score--1');
const diceEl = document.querySelector('.dice');
const current0El = document.getElementById('current--0');
const current1El = document.getElementById('current--1');
const btnNew = document.querySelector('.btn--new');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
