/* For any Question write me an Email at: codeWithJad@gmail.com */

const yearEl = document.querySelector('.year');
const currentYear = new Date().getFullYear();
yearEl.textContent = currentYear;
