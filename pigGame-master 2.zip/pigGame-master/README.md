# pigGame
Pig is a simple dice game. Players take turns to roll a single die as many times as they wish, adding all roll results to a running total, but losing their gained score for the turn if they roll a 1.

In this Game I used HTML5(DOM API), CSS3(FlexBox) & JavaScript. The Code is pretty well organized & is clean.   

https://piggame-jad.netlify.app/ 
